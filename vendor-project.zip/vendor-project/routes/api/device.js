const express = require('express');
const router = express.Router();


const devices = [
  {
    id: 'DPZ001',
    name: "Dispensor 1",
    deviceStatus: true,
    availableQty: 10,
    unitPrice: 5,
    dispenseMultiple: true
  },
  {
    id: 'DPZ002',
    name: "Dispensor 2",
    deviceStatus: true,
    availableQty: 0,
    unitPrice: 5,
    dispenseMultiple: false
  },
  {
    id: 'DPZ003',
    name: "Dispensor 3",
    deviceStatus: false,
    availableQty: 10,
    unitPrice: 5,
    dispenseMultiple: true
  },
  {
    id: 'DPZ004',
    name: "Dispensor 4",
    deviceStatus: true,
    availableQty: 10,
    unitPrice: 5,
    dispenseMultiple: false
  },
]


// @route    GET api/device
// @desc     Get device details by deviceId
// @access   Private
router.get('/:deviceId', async (req, res) => {

  const deviceId = req.params.deviceId;

  try {
    const device = devices.filter((e) => e.id === deviceId);

    if(device) {
      res.json(device);
    }
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
});

module.exports = router;